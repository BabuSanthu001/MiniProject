package com.demoeg.projdemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.demoeg.projdemo.model.User;
import com.demoeg.projdemo.repository.UserRepository;

@SpringBootApplication
public class ProjdemoApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(ProjdemoApplication.class, args);
	}
	
	@Autowired
	private UserRepository userRepository;

	@Override
	public void run(String... args) throws Exception {
		this.userRepository.save(new User("Santhu","FirstClass","santhu001@gamil.com","Madurai","Chennai","Two","Indico"));
		this.userRepository.save(new User("Moni","SecondClass","moni1243@gamil.com","Chennai","Delhi","Eight","GoAir"));
		this.userRepository.save(new User("Pavi","BusinessClass","pavicute123@gamil.com","Coimbatore","Chennai","Four","AirIndia"));
		this.userRepository.save(new User("Sri","PermiumClass","sri1807@gamil.com","America","Delhi","One","SpiceJet"));
		this.userRepository.save(new User("Bala","BusinessClass","balareddy1234@gamil.com","Canada","Kashmir","Three","AirAsia"));
		this.userRepository.save(new User("Rupi","EconomyClass","rupiman@gamil.com","NewYork","bangalore","Two","TruJet"));
		this.userRepository.save(new User("Reddy","SecondClass","reddychan@gamil.com","Bangalore","Hyderabad","Five","Vistara"));
		this.userRepository.save(new User("Chinttu","FirstClass","chinttu6890@gamil.com","Dubai","Goa","One","Indico"));		
	}

}
