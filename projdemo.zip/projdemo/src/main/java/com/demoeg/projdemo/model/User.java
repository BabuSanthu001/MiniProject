package com.demoeg.projdemo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="users")
public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@Column(name="name")
	private String name;	
	private String booking_class;	
	private String email;
	private String destination;
	private String arrival;
	private String no_person;
	private String fight_name;
	
	
	public User() {
		
		
	}
		
	public User(String name, String booking_class, String email, String destination, String arrival, String no_person,
			String fight_name) {
		super();
		this.name = name;
		this.booking_class = booking_class;
		this.email = email;
		this.destination = destination;
		this.arrival = arrival;
		this.no_person = no_person;
		this.fight_name = fight_name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBooking_class() {
		return booking_class;
	}

	public void setBooking_class(String booking_class) {
		this.booking_class = booking_class;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getArrival() {
		return arrival;
	}

	public void setArrival(String arrival) {
		this.arrival = arrival;
	}

	public String getNo_person() {
		return no_person;
	}

	public void setNo_person(String no_person) {
		this.no_person = no_person;
	}

	public String getFight_name() {
		return fight_name;
	}

	public void setFight_name(String fight_name) {
		this.fight_name = fight_name;
	}





}
