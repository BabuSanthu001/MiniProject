package com.demoeg.projdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
