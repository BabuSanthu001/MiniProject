import React from 'react';
import ReactDOM from 'react-dom';
import UserService from '../services/UseService';


class UserComponent extends React.Component{
    constructor(props){
        super(props)
        this.state={
            users:[]
        }
    }

    componentDidMount(){
        UserService.getUsers().then((response)=>{
            this.setState({users: response.data})

        });
    }

    render(){
        return(
            <div style={{backgroundColor:'pink',height:'100%',width:'100%'}}>
                <h2 style={{color:'brown', textAlign:'left',fontFamily:'initial'}}>Airline Reservation</h2>
                
                <h4 style={{color:'red', textAlign:'left',fontFamily:'fantasy'}}>Type Of Class Tickets</h4>
                <ol>
                    {
                        this.state.users.map(
                            users=>(
                                <li type='numbers' key={users.id} style={{color:'darkviolet', textAlign:'left',fontFamily:'-moz-initial'}}>
                                    {users.booking_class}

                                </li>
                            ))
                    }
                </ol>

                {/*
                <table className="table table-striped">
                    
                    <thead>
                        <tr>
                            <td>User Id</td>
                            <td>FirstName</td>
                            <td>LastName</td>
                            <td>Email</td>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.users.map(
                                users=>
                                <tr key={users.id}>
                                    <td>{users.id}</td>
                                    <td>{users.firstname}</td>
                                    <td>{users.lastname}</td>
                                    <td>{users.email}</td>
                                </tr>
                            )
                        }
                    </tbody>
                </table> 
               */}
            </div>
        )
    }
}

export default UserComponent