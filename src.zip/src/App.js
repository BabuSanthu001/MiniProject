import logo from './logo.svg';
import './App.css';
import UserComponent from './components/UserComponent'

function App() {
  return (
    <div className="App">
      <UserComponent/>
      
      
    </div>
  );
}

export default App;
